const form = document.getElementById("bookingForm");
const service = document.getElementById("service");
const dateInput = document.getElementById("date");
const timeInput = document.getElementById("time");
const propertyInputs = [...document.querySelectorAll('input[name="property"]')];

const today = new Date();
dateInput.min = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);

const prettyDate = value => value ? new Date(value + "T12:00:00").toLocaleDateString(undefined, {day:"numeric",month:"short",year:"numeric"}) : "Not selected";
const selectedProperty = () => propertyInputs.find(input => input.checked)?.value || "";

function updateSummary() {
  document.getElementById("sumService").textContent = service.value || "Not selected";
  document.getElementById("sumProperty").textContent = selectedProperty() || "Not selected";
  document.getElementById("sumDate").textContent = prettyDate(dateInput.value);
  document.getElementById("sumTime").textContent = timeInput.value || "Not selected";
}
form.addEventListener("input", updateSummary);
form.addEventListener("change", updateSummary);

const requestedService = new URLSearchParams(location.search).get("service");
if (requestedService && [...service.options].some(option => option.value === requestedService || option.text === requestedService)) {
  service.value = requestedService;
  updateSummary();
}

form.addEventListener("submit", event => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const data = Object.fromEntries(new FormData(form).entries());
  data.createdAt = new Date().toISOString();
  data.reference = "PC-" + Date.now().toString().slice(-8);
  let bookings = [];
  try { bookings = JSON.parse(localStorage.getItem("pestcareBookings") || "[]"); } catch {}
  bookings.push(data);
  try { localStorage.setItem("pestcareBookings", JSON.stringify(bookings)); }
  catch { alert("Could not save this request in browser storage. Please check your browser settings."); return; }

  document.getElementById("successText").textContent = `Your ${data.service} request for ${prettyDate(data.date)} (${data.time}) has been saved in this browser.`;
  document.getElementById("reference").textContent = "Reference: " + data.reference;
  document.querySelector(".booking-layout").hidden = true;
  document.querySelector(".intro").hidden = true;
  document.getElementById("successPanel").hidden = false;
  document.getElementById("successPanel").scrollIntoView({behavior:"smooth",block:"start"});
});
document.getElementById("newBooking").addEventListener("click", () => {
  form.reset(); updateSummary();
  document.getElementById("successPanel").hidden = true;
  document.querySelector(".booking-layout").hidden = false;
  document.querySelector(".intro").hidden = false;
  window.scrollTo({top:0,behavior:"smooth"});
});
document.getElementById("printBooking").addEventListener("click", () => window.print());
updateSummary();
