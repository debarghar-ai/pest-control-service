// Small homepage interaction helpers.
document.addEventListener("DOMContentLoaded", () => {
  // Service cards link directly to the booking form; the hero CTA does the same.
  document.querySelectorAll('a[href="booking.html"]').forEach(link => {
    link.addEventListener("click", () => {
      // Normal navigation is intentional so the booking page loads reliably with Live Server.
    });
  });
});
